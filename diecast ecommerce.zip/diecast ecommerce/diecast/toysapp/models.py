from typing import Reversible
from django.db import models
from django.contrib.auth.models import User


# Create your models here.


class Customer(models.Model):
    user = models.OneToOneField(User, null=False, blank=False, on_delete=models.CASCADE)

    # extra fields will come here
    # phone_field = models.CharField(max_length=12, blank=False)

    def __str__(self):
        return self.user.username

from django.db import models
from django.contrib.auth.models import User


# class Category(models.Model):
#     name = models.CharField(max_length=100)
   

#     def _str_(self):
#         return self.name

class Product(models.Model):
    title = models.CharField(max_length=200)
    description = models.TextField()
    price = models.IntegerField()
    image = models.ImageField(upload_to='products/')
    # category = models.ForeignKey(Category, on_delete=models.CASCADE)
    stock = models.PositiveIntegerField(default=0)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def _str_(self):
        return self.title


class Cart(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name="cart")
    active = models.BooleanField(default=True) 

    def _str_(self):
        return f"Cart for {self.user.username}"

class CartItem(models.Model):
    cart = models.ForeignKey(Cart, on_delete=models.CASCADE, related_name="items")
    product = models.ForeignKey(Product, on_delete=models.CASCADE)
    quantity = models.PositiveIntegerField(default=1)



    @property
    def total_price(self):
        return self.product.price * self.quantity

    def _str_(self):
        return f"{self.quantity} of {self.product.title}"


# class Cart(models.Model):
#     user = models.OneToOneField(User, on_delete=models.CASCADE)
#     created_at = models.DateTimeField(auto_now_add=True)

#     def _str_(self):
#         return f"Cart of {self.user.username}"

# class CartItem(models.Model):
#     cart = models.ForeignKey(Cart, related_name='items', on_delete=models.CASCADE)
#     product = models.ForeignKey(Product, on_delete=models.CASCADE)
#     quantity = models.PositiveIntegerField(default=1)

#     def _str_(self):
#         return f"{self.quantity} of {self.product.title} in cart of {self.cart.user.username}"

#     @property
#     def total_price(self):
#         return self.product.price * self.quantity
class Order(models.Model):
        user = models.ForeignKey(User, on_delete=models.CASCADE)
        shipping_address = models.TextField()
        items = models.ManyToManyField(CartItem)
        created_at = models.DateTimeField(auto_now_add=True)
        total_price = models.DecimalField(max_digits=10, decimal_places=2, default=0)
        payment_method = models.CharField(max_length=50, choices=[
        ('Credit Card', 'Credit Card'),
        ('PayPal', 'PayPal')],
        
        default='Credit Card'  # This will automatically be used for all new and existing rows
    )
    


        def calculate_total(self):
            self.total_price = sum(item.product.price * item.quantity for item in self.items.all())
            self.save()

            def _str_(self):
                return f"Order {self.id} by {self.user.username}"
class OrderItem(models.Model):
    order = models.ForeignKey(Order, related_name='order_items', on_delete=models.CASCADE)
    product = models.ForeignKey(Product, on_delete=models.CASCADE)
    quantity = models.PositiveIntegerField(default=1)

    @property
    def total_price(self):
        return self.product.price * self.quantity
