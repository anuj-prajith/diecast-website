from django.urls import path
from .import views
from django.contrib.auth.views import LogoutView 

urlpatterns = [
    path('user_login',views.user_login,name='user_login'),
    path('user_registration',views.user_registration,name='user_registration'),
    path('user_logout',views.user_logout,name='user_logout'),
    path('',views.home,name='home'),
    path('products', views.product_list, name='productlist'),
    path('product/<int:product_id>/', views.productdetail, name='product_detail'),
    path('add-to-cart/<int:product_id>/', views.add_to_cart, name='add_to_cart'),
    path('cart/', views.cart, name='cart'),
    path('checkout/', views.checkout, name='checkout'),  
    path('profile/', views.profile, name='profile'),
    path('purchasehistory/', views.purchase_history, name='purchasehistory'),
    path('cart/remove/<int:item_id>/', views.remove_from_cart, name='remove_from_cart'),
    path('checkout/', views.checkout, name='checkout'),
]
