from django.contrib import admin
from .models import *
# Register your models here.

admin.site.register(Customer)
from django.contrib import admin
from .models import Product
# Category



class ProductAdmin(admin.ModelAdmin):
    list_display = ('title', 'price', 'created_at', 'updated_at')  # Make sure these fields exist in your model
    search_fields = ('title',)
    # list_filter = ('category',)
    # list_filter = ('title',)


    
# Ensure you don't have another line like:
admin.site.register(Product, ProductAdmin) 
# admin.site.register(Category)