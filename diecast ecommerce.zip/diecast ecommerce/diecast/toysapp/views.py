from django.shortcuts import render,redirect
from django.contrib.auth.models import User
from .models import *
from django.contrib.auth import authenticate,login,logout
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import login,authenticate,logout
from django.contrib.auth.decorators import login_required
from .models import Product
from .models import  Cart, CartItem,Order,OrderItem
from django.views.decorators.http import require_POST
from django.http import JsonResponse
from django.shortcuts import get_object_or_404, redirect, render
from django.shortcuts import get_object_or_404, redirect
from django.contrib import messages

# Create your views here.
def user_login(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password=request.POST.get('password')
        user=authenticate(username=username,password=password)
        if user is not None:
            login(request,user)
            return redirect('home')
    return render(request,'login.html')

def user_registration(request):
    if request.method=="POST":
        username=request.POST.get('username')
        email=request.POST.get('email')
        password=request.POST.get('password')
        confirm_password=request.POST.get('confirm_password')
        phone=request.POST.get('phone')
        if password==confirm_password:
            if User.objects.filter(username=username).exists():
                print("Username already exists")
                return redirect('user_registration')
            else:
                if User.objects.filter(email=email).exists():
                    print("Email already exists")
                    return redirect('user_registration')
                else:
                    user=User.objects.create_user(username=username,email=email,password=password)
                    user.save()
                    our_user=authenticate(username=username,password=password)
                    if our_user is not None:
                        login(request,user)
                        return redirect('home')
        else:
            print("Password and confirm password do not match")
            return redirect('user_registration')
    return render(request,'register.html')
    
def user_logout(request):
    logout(request)
    return redirect('home')

def home(request):
    products = Product.objects.all()  # Get all products ordered by priority
    return render(request, 'base.html', {'products': products})
def product_list(request):
    products = Product.objects.all()
    # categories = Category.objects.all()
    return render(request, 'productlist.html', {'products': products})
# 'categories': categories}

def productdetail(request, product_id):
    product = get_object_or_404(Product, id=product_id)
    return render(request, 'productdetail.html', {'product': product})

@login_required
def add_to_cart(request, product_id):
    product = get_object_or_404(Product, id=product_id)
    quantity = int(request.POST.get('quantity', 1))
    # Get or create the user's cart
    cart, created = Cart.objects.get_or_create(user=request.user)
    # Get or create a CartItem for this product in the cart
    cart_item, created = CartItem.objects.get_or_create(cart=cart, product=product)
    if not created:
        # If it already exists, increment the quantity
        cart_item.quantity += 1
    else:
        # If it's a new item, set the quantity
        cart_item.quantity = quantity
    cart_item.save()

    return redirect('cart')

    # cart_item.save()
    # return redirect('cart')

@login_required
def cart(request):
    # Get the user's cart and its items
    cart, created = Cart.objects.get_or_create(user=request.user)
    cart_items = cart.items.all()
    total_price = sum(item.total_price for item in cart_items)

    context = {
        'cart_items': cart_items,
        'total_price': total_price,
    }
    return render(request, 'cart.html', context)
@require_POST
@login_required
def remove_from_cart(request, item_id):
    try:
        # Find the active cart for the current user
        cart = get_object_or_404(Cart, user=request.user, active=True)
        
        # Find and remove the item
        cart_item = get_object_or_404(cart.items, id=item_id)
        cart_item.delete()
        
        # Add a success message
        messages.success(request, "Item removed from cart.")
        return JsonResponse({'success': True})
    except Exception as e:
        # Add an error message
        messages.error(request, f"Error: {str(e)}")
        return JsonResponse({'success': False, 'error': str(e)})
    
@login_required
def checkout(request):
    # Get or create the user's cart
    cart, created = Cart.objects.get_or_create(user=request.user)
    cart_items = cart.items.all()

    # If the cart is empty, redirect the user to the cart page
    if not cart_items:
        return redirect('cart')

    # Calculate the total price for the order
    total_price = sum(item.total_price for item in cart_items)

    if request.method == 'POST':
        # Retrieve form data from the request
        shipping_address = request.POST.get('shipping_address')
        payment_method = request.POST.get('payment_method')

        if shipping_address and payment_method:
            # Create an order
            order = Order.objects.create(
                user=request.user,
                shipping_address=shipping_address,
                payment_method=payment_method,
                total_price=total_price
            )

            # Create OrderItems for each CartItem
            for item in cart_items:
                OrderItem.objects.create(
                    order=order,
                    product=item.product,
                    quantity=item.quantity
                )

            # Clear the user's cart after the order is placed
            cart_items.delete()

            # Redirect the user to their profile or another page
            return redirect('profile')  # You can change this to another page, like 'order_confirmation'

    context = {
        'cart_items': cart_items,
        'total_price': total_price
    }

    return render(request, 'checkout.html', context)

@login_required
def profile(request):
    orders = Order.objects.filter(user=request.user)
    return render(request, 'profile.html', {'orders': orders})
# In views.py

def purchase_history(request):
    orders = Order.objects.filter(user=request.user).order_by('-created_at')
    return render(request, 'purchasehistory.html', {'orders': orders})